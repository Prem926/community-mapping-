import folium
import requests
from folium import plugins

# Ola Krutam API Key
API_KEY = 'B0y8oUw7edtX6USoRs4s'

def get_directions(origin, destination, waypoints=None):
    url = f"https://api.olamaps.io/routing/v1/directions?origin={origin}&destination={destination}&api_key={API_KEY}"
    
    if waypoints:
        url += f"&waypoints={waypoints}"
    
    headers = {'X-Request-Id': 'unique-request-id'}
    response = requests.post(url, headers=headers)

    print(response.json())
    return response.json()

def mark_flooded_area(map_obj, lat, lon, radius=500):
    # Mark the flooded area
    folium.Circle(
        location=(lat, lon),
        radius=radius,
        color='darkblue',
        fill=True,
        fill_opacity=0.5,
        popup="Flooded Area"
    ).add_to(map_obj)

def plot_route(map_obj, route):
    for leg in route['routes'][0]['legs']:
        polyline = leg['steps'][0]['geometry']['coordinates']
        folium.PolyLine(locations=[(coord[1], coord[0]) for coord in polyline], color="green", weight=5, opacity=0.7).add_to(map_obj)

def main():
    # User inputs for source, destination, and flooded area
    source_lat = float(input("Enter source latitude: "))
    source_lon = float(input("Enter source longitude: "))
    destination_lat = float(input("Enter destination latitude: "))
    destination_lon = float(input("Enter destination longitude: "))
    flood_lat = float(input("Enter flooded area latitude: "))
    flood_lon = float(input("Enter flooded area longitude: "))
    
    # Create map centered on source
    map_obj = folium.Map(location=[source_lat, source_lon], zoom_start=13)
    
    # Mark the flooded area
    mark_flooded_area(map_obj, flood_lat, flood_lon)

    # Get directions avoiding the flooded area
    origin = f"{source_lat},{source_lon}"
    destination = f"{destination_lat},{destination_lon}"
    waypoints = f"{flood_lat},{flood_lon}"

    # Get alternative routes
    directions = get_directions(origin, destination, waypoints)
    
    # Plot routes
    if 'routes' in directions:
        plot_route(map_obj, directions)
        print("Alternative route found and plotted on the map.")
    else:
        print("No alternative route found.")
    
    # Save and display the map
    map_obj.save("map_with_routes.html")
    print("Map saved as map_with_routes.html")

if __name__ == "__main__":
    main()
