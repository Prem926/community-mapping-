import folium
import requests
import geocoder
from math import radians, sin, cos, sqrt, atan2
import pyttsx3  # For voice assistance
import polyline

# Initialize voice engine for voice assistance
engine = pyttsx3.init()

# API Key (Replace with your actual key)
API_KEY = 'YFJkfYydYN3zEwadh3YLTa2YiP7Ur6Du8Upv6xdM'

# Vehicle speed (average in km/h) for calculating ETA based on vehicle type
VEHICLE_SPEEDS = {
    "cycle": 15,
    "walking": 5,
    "2-wheeler": 40,
    "4-wheeler": 60
}

# Function to get directions from the API
def get_directions(origin, destination, vehicle, waypoints=None, alternatives=True):
    url = f"https://api.olamaps.io/routing/v1/directions?origin={origin}&destination={destination}&api_key={API_KEY}&alternatives={str(alternatives).lower()}"
    
    if waypoints:
        url += f"&waypoints={waypoints}"
    
    headers = {'X-Request-Id': 'unique-request-id'}
    response = requests.post(url, headers=headers)
    
    if response.status_code == 200:
        directions = response.json()
        if 'routes' in directions:
            for route in directions['routes']:
                # Ensure distance and duration are calculated
                if 'distance' not in route:
                    distance_km = route.get('distance', 0) / 1000
                    if distance_km > 0:
                        time_hours = distance_km / VEHICLE_SPEEDS.get(vehicle, 60)
                        route['duration'] = time_hours * 3600  # Convert hours to seconds
                return directions
        else:
            print("Routes not found in API response.")
            return None
    else:
        print(f"API request failed with status code {response.status_code}")
        return None

# Function to calculate distance using Haversine formula
def haversine_distance(lat1, lon1, lat2, lon2):
    R = 6371  # Radius of the Earth in km
    dLat = radians(lat2 - lat1)
    dLon = radians(lon2 - lon1)
    a = sin(dLat / 2) ** 2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(dLon / 2) ** 2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    return R * c  # Distance in km

# Function to mark flooded areas with different severity levels
def mark_flooded_area(map_obj, lat, lon, severity):
    color = {1: 'lightblue', 2: 'blue', 3: 'darkblue'}[severity]
    radius = {1: 500, 2: 1000, 3: 1500}[severity]
    folium.Circle(
        location=(lat, lon),
        radius=radius,
        color=color,
        fill=True,
        fill_opacity=0.5,
        popup=f"Flooded Area - Severity: {severity}"
    ).add_to(map_obj)

# Function to plot the route and handle flooded zones
def plot_route(map_obj, route, flooded_areas, radius=1000, vehicle='4-wheeler'):
    if 'overview_polyline' not in route:
        print("Polyline data not found in route.")
        return
    
    decoded_polyline = polyline.decode(route['overview_polyline'])

    for i in range(len(decoded_polyline) - 1):
        segment_start = decoded_polyline[i]
        segment_end = decoded_polyline[i + 1]
        lat1, lon1 = segment_start
        lat2, lon2 = segment_end

        segment_color = "green"
        for flood_lat, flood_lon, severity in flooded_areas:
            if haversine_distance(lat1, lon1, flood_lat, flood_lon) <= radius / 1000 or haversine_distance(lat2, lon2, flood_lat, flood_lon) <= radius / 1000:
                if severity == 3:
                    segment_color = "red"
                elif severity == 2 and vehicle != '4-wheeler':
                    segment_color = "yellow"
                elif severity == 1:
                    segment_color = "lightblue"
                break

        folium.PolyLine(
            locations=[segment_start, segment_end],
            color=segment_color,
            weight=5,
            opacity=0.7,
            popup=f"Vehicle: {vehicle}, Segment ETA: {route.get('duration', 'N/A')} seconds"
        ).add_to(map_obj)

# Voice assistance function
def voice_assistance(message):
    engine.say(message)
    engine.runAndWait()

# Function to get the current user's geolocation
def get_geolocation():
    g = geocoder.ip('me')
    return g.latlng

# Main function to handle user input and display the map
def main():
    # Get geolocation
    user_geolocation = get_geolocation()
    
    # User inputs for source, destination, and flooded areas
    print(f"Your current location is: {user_geolocation}")
    source_lat = user_geolocation[0] or float(input("Enter source latitude: "))
    source_lon = user_geolocation[1] or float(input("Enter source longitude: "))
    destination_lat = float(input("Enter destination latitude: "))
    destination_lon = float(input("Enter destination longitude: "))
    
    # Select vehicle type
    vehicle_type = input("Enter vehicle type (cycle, walking, 2-wheeler, 4-wheeler): ").lower()

    # Flooded areas input with vehicle restriction based on severity
    flooded_areas = []
    while True:
        flood_lat = float(input("Enter flooded area latitude: "))
        flood_lon = float(input("Enter flooded area longitude: "))
        severity_input = input("Enter flood severity (1: low, 2: medium, 3: high): ").strip().lower()
        
        severity = {"low": 1, "medium": 2, "high": 3}.get(severity_input)
        if severity is None:
            print("Invalid flood severity. Please enter 'low', 'medium', or 'high'.")
            continue

        # Add flood info to list
        flooded_areas.append((flood_lat, flood_lon, severity))

        # Check vehicle restrictions based on flood severity
        if severity == 3:
            print("High severity flood detected. No vehicles should go through this area.")
            voice_assistance("High severity flood detected. Suggesting alternative routes.")
            break
        elif severity == 2 and vehicle_type != '4-wheeler':
            print("Medium severity flood detected. Only 4-wheelers can pass.")
            voice_assistance("Medium severity flood detected. Only 4-wheelers can pass.")
        elif severity == 1:
            print("Low severity flood detected. All vehicles can pass.")

        more_floods = input("Are there more flooded areas? (yes/no): ").strip().lower()
        if more_floods != "yes":
            break

    # Get directions and plot the route
    origin = f"{source_lat},{source_lon}"
    destination = f"{destination_lat},{destination_lon}"
    directions = get_directions(origin, destination, vehicle_type, alternatives=True)

    # Create map centered on source
    map_obj = folium.Map(location=[source_lat, source_lon], zoom_start=13, control_scale=True)

    # Advanced layers: Adding terrain, satellite, and other layer options
    folium.TileLayer('Stamen Terrain').add_to(map_obj)
    folium.TileLayer('cartodb positron').add_to(map_obj)
    folium.LayerControl().add_to(map_obj)

    # Mark all flooded areas
    for lat, lon, severity in flooded_areas:
        mark_flooded_area(map_obj, lat, lon, severity)

    # Plot routes with flood area checks
    if 'routes' in directions:
        for route in directions['routes']:
            plot_route(map_obj, route, flooded_areas, radius=1500, vehicle=vehicle_type)
            # Voice guidance for navigation
            voice_assistance(f"Route loaded, travel time is {route.get('duration', 'N/A')} seconds.")

    else:
        print("No route found.")
        voice_assistance("No route found. Please check the input.")

    # Mark start and end points with custom icons
    folium.Marker(
        location=[source_lat, source_lon],
        popup="Start Point",
        icon=folium.Icon(color='green', icon='play')
    ).add_to(map_obj)

    folium.Marker(
        location=[destination_lat, destination_lon],
        popup="Destination Point",
        icon=folium.Icon(color='red', icon='flag')
    ).add_to(map_obj)

    # Save and display the map
    map_obj.save("map_with_routes.html")
    print("Map saved as map_with_routes.html. Open this file in a browser to view the map.")
    voice_assistance("Map generated successfully. Open map_with_routes.html to view.")

if __name__ == "__main__":
    main()
