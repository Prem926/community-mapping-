import folium
import requests
from math import radians, sin, cos, sqrt, atan2
import polyline
import json

# Ola Krutam API Key
API_KEY = 'YFJkfYydYN3zEwadh3YLTa2YiP7Ur6Du8Upv6xdM'

def get_directions(origin, destination, waypoints=None, alternatives=True):
    url = f"https://api.olamaps.io/routing/v1/directions?origin={origin}&destination={destination}&api_key={API_KEY}&alternatives={str(alternatives).lower()}"
    
    if waypoints:
        url += f"&waypoints={waypoints}"
    
    headers = {'X-Request-Id': 'unique-request-id'}
    response = requests.post(url, headers=headers)
    return response.json()

def mark_flooded_area(map_obj, lat, lon, radius=1000, label="Flooded Area"):
    folium.Circle(
        location=(lat, lon),
        radius=radius,
        color='darkblue',
        fill=True,
        fill_opacity=0.5,
        popup=label
    ).add_to(map_obj)

def haversine_distance(lat1, lon1, lat2, lon2):
    R = 6371  # Radius of the Earth in km
    dLat = radians(lat2 - lat1)
    dLon = radians(lon2 - lon1)
    a = sin(dLat / 2) ** 2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(dLon / 2) ** 2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    return R * c  # Distance in km

def plot_route(map_obj, route, flooded_areas, radius=1000):
    decoded_polyline = polyline.decode(route['overview_polyline'])
    
    for i in range(len(decoded_polyline) - 1):
        segment_start = decoded_polyline[i]
        segment_end = decoded_polyline[i + 1]
        lat1, lon1 = segment_start
        lat2, lon2 = segment_end
        
        segment_color = "green"
        for flood_lat, flood_lon in flooded_areas:
            if haversine_distance(lat1, lon1, flood_lat, flood_lon) <= radius / 1000 or haversine_distance(lat2, lon2, flood_lat, flood_lon) <= radius / 1000:
                segment_color = "red"
                break
        
        folium.PolyLine(
            locations=[segment_start, segment_end],
            color=segment_color,
            weight=5,
            opacity=0.7
        ).add_to(map_obj)

def main():
    # User inputs for source, destination, and flooded areas
    source_lat = float(input("Enter source latitude: "))
    source_lon = float(input("Enter source longitude: "))
    destination_lat = float(input("Enter destination latitude: "))
    destination_lon = float(input("Enter destination longitude: "))

    # Prompt for multiple flooded areas
    flooded_areas = []
    while True:
        flood_lat = float(input("Enter flooded area latitude: "))
        flood_lon = float(input("Enter flooded area longitude: "))
        flooded_areas.append((flood_lat, flood_lon))
        more_floods = input("Are there more flooded areas? (yes/no): ")
        if more_floods.lower() != "yes":
            break

    # Create map centered on source
    map_obj = folium.Map(location=[source_lat, source_lon], zoom_start=13)
    
    # Mark all flooded areas
    for idx, (flood_lat, flood_lon) in enumerate(flooded_areas, start=1):
        mark_flooded_area(map_obj, flood_lat, flood_lon, radius=1000, label=f"Flooded Area {idx}")

    # Get directions
    origin = f"{source_lat},{source_lon}"
    destination = f"{destination_lat},{destination_lon}"
    waypoints = None

    # Get alternative routes
    directions = get_directions(origin, destination, waypoints, alternatives=True)

    # Plot routes with flood area checks
    if 'routes' in directions:
        for idx, route in enumerate(directions['routes'][:10]):  # Show up to 10 routes
            plot_route(map_obj, route, flooded_areas, radius=1500)
        print("Routes plotted on the map.")
    else:
        print("No route found.")

    # Adding additional features: display markers for start and end points
    folium.Marker(location=[source_lat, source_lon], popup="Start Point", icon=folium.Icon(color='green')).add_to(map_obj)
    folium.Marker(location=[destination_lat, destination_lon], popup="Destination Point", icon=folium.Icon(color='red')).add_to(map_obj)

    # Save and display the map
    map_obj.save("map_with_routes.html")
    print("Map saved as map_with_routes.html")

if __name__ == "__main__":
    main()