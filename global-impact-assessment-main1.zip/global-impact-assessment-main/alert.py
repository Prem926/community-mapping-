from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/receive_alert', methods=['POST'])
def receive_alert():
    alert_data = request.json
    # Handle the received alert data here
    print("Received Flood Alert:", alert_data)
    return jsonify({"message": "Alert received successfully.", "received_data": alert_data})

if __name__ == '_main_':
    app.run(host='0.0.0.0', port=5001, debug=True)  # Make sure this port matches the one used in the sender API URL